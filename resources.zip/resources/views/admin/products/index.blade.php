@extends('layouts.admin')

@section('title', 'Produk')

@section('content')

<div class="page-header">
    <div>
        <h1 class="page-title">Manajemen Produk</h1>
        <p class="page-subtitle">Kelola menu, stok, dan ketersediaan</p>
    </div>
    <button onclick="openModal('add')" class="btn btn-primary btn-sm">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        Tambah Produk
    </button>
</div>

@if($errors->any())
<div class="alert alert-error mb-4">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
    {{ $errors->first() }}
</div>
@endif

<div class="table-wrap">
    <div class="overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th class="text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $p)
                <tr>
                    <td>
                        <p class="cell-primary">{{ $p->name }}</p>
                        @if($p->description)
                        <p class="text-xs text-gray-400 mt-0.5 max-w-xs truncate">{{ $p->description }}</p>
                        @endif
                        <p class="text-xs text-gray-300 mt-0.5 font-mono">#{{ $p->id }}</p>
                    </td>
                    <td>
                        <span class="font-semibold text-gray-800">Rp {{ number_format($p->price, 0, ',', '.') }}</span>
                    </td>
                    <td>
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="font-bold text-sm {{ $p->stock <= 5 ? 'text-red-500' : 'text-gray-900' }}">
                                {{ $p->stock }}
                            </span>
                            <form action="{{ route('admin.products.addStock', $p->id) }}" method="POST"
                                  class="flex items-center gap-1">
                                @csrf
                                <input type="number" name="stock" min="1" max="9999"
                                       placeholder="+stok"
                                       class="input text-center" style="width:56px; padding:5px 6px; font-size:12px;">
                                <button type="submit" class="btn btn-sm"
                                        style="background:var(--blue-50); color:var(--blue-700); border-color:var(--blue-100); padding:5px 10px;">
                                    +
                                </button>
                            </form>
                        </div>
                    </td>
                    <td>
                        <span class="badge {{ $p->is_available ? 'badge-green' : 'badge-red' }}">
                            {{ $p->is_available ? 'Aktif' : 'Nonaktif' }}
                        </span>
                    </td>
                    <td>
                        <div class="flex items-center justify-end gap-1.5 flex-wrap">
                            <button
                                onclick="openEdit({{ $p->id }}, '{{ addslashes($p->name) }}', {{ $p->price }}, {{ $p->stock }}, '{{ addslashes($p->description ?? '') }}')"
                                class="btn btn-ghost btn-sm">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                Edit
                            </button>

                            <form action="{{ route('admin.products.toggle', $p->id) }}" method="POST" class="inline">
                                @csrf
                                <button class="btn btn-sm" style="background:var(--orange-50); color:var(--orange-700); border-color:var(--orange-200);">
                                    {{ $p->is_available ? 'Matikan' : 'Aktifkan' }}
                                </button>
                            </form>

                            <form action="{{ route('admin.products.delete', $p->id) }}" method="POST" class="inline"
                                  onsubmit="return confirm('Hapus produk \'{{ addslashes($p->name) }}\'?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-danger btn-sm">
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5">
                        <div class="empty-state">
                            <div class="empty-icon" style="font-size:20px;">🍽️</div>
                            <p class="empty-title">Belum ada produk</p>
                            <p class="empty-desc">Klik "Tambah Produk" untuk mulai.</p>
                        </div>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- Modal: Tambah --}}
<div id="modal-add" class="modal-backdrop hidden">
    <div class="modal">
        <div class="flex items-center justify-between mb-4">
            <h2 class="modal-title">Tambah Produk</h2>
            <button onclick="closeModal('add')" class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--gray-400);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <form action="{{ route('admin.products.store') }}" method="POST" class="space-y-3">
            @csrf
            <div class="form-group">
                <label class="form-label">Nama Produk <span style="color:var(--orange-500);">*</span></label>
                <input type="text" name="name" required class="input" placeholder="Contoh: Siomay Ayam">
            </div>
            <div class="form-group">
                <label class="form-label">Harga (Rp) <span style="color:var(--orange-500);">*</span></label>
                <input type="number" name="price" required min="0" class="input" placeholder="15000">
            </div>
            <div class="form-group">
                <label class="form-label">Stok Awal <span style="color:var(--orange-500);">*</span></label>
                <input type="number" name="stock" required min="0" class="input" placeholder="50">
            </div>
            <div class="form-group">
                <label class="form-label">Deskripsi <span class="text-gray-300">(opsional)</span></label>
                <textarea name="description" class="textarea" rows="2" placeholder="Deskripsi singkat..."></textarea>
            </div>
            <div class="flex gap-2 pt-1">
                <button type="button" onclick="closeModal('add')" class="btn btn-secondary flex-1">Batal</button>
                <button type="submit" class="btn btn-primary flex-1">Simpan</button>
            </div>
        </form>
    </div>
</div>

{{-- Modal: Edit --}}
<div id="modal-edit" class="modal-backdrop hidden">
    <div class="modal">
        <div class="flex items-center justify-between mb-4">
            <h2 class="modal-title">Edit Produk</h2>
            <button onclick="closeModal('edit')" class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--gray-400);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <form id="edit-form" method="POST" class="space-y-3">
            @csrf @method('PUT')
            <div class="form-group">
                <label class="form-label">Nama Produk <span style="color:var(--orange-500);">*</span></label>
                <input type="text" id="edit-name" name="name" required class="input">
            </div>
            <div class="form-group">
                <label class="form-label">Harga (Rp) <span style="color:var(--orange-500);">*</span></label>
                <input type="number" id="edit-price" name="price" required min="0" class="input">
            </div>
            <div class="form-group">
                <label class="form-label">Stok</label>
                <input type="number" id="edit-stock" name="stock" required min="0" class="input">
            </div>
            <div class="form-group">
                <label class="form-label">Deskripsi</label>
                <textarea id="edit-description" name="description" class="textarea" rows="2"></textarea>
            </div>
            <div class="flex gap-2 pt-1">
                <button type="button" onclick="closeModal('edit')" class="btn btn-secondary flex-1">Batal</button>
                <button type="submit" class="btn btn-primary flex-1">Update</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(type) { document.getElementById('modal-' + type).classList.remove('hidden'); }
function closeModal(type) { document.getElementById('modal-' + type).classList.add('hidden'); }

function openEdit(id, name, price, stock, description) {
    document.getElementById('edit-name').value        = name;
    document.getElementById('edit-price').value       = price;
    document.getElementById('edit-stock').value       = stock;
    document.getElementById('edit-description').value = description;
    document.getElementById('edit-form').action       = '/admin/products/' + id;
    openModal('edit');
}

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeModal('add'); closeModal('edit'); }
});

// Close on backdrop click
['modal-add','modal-edit'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) closeModal(id.replace('modal-',''));
    });
});
</script>

@endsection
