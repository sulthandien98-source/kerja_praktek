<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <!DOCTYPE html>

<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1">

<meta
    name="csrf-token"
    content="{{ csrf_token() }}">

<meta
    name="description"
    content="Dimsum Mak'Angga - Pemesanan Dimsum Online">

<meta
    name="theme-color"
    content="#f97316">

<title>{{ config('app.name', "Dimsum Mak'Angga") }}</title>

<link
    rel="icon"
    href="{{ asset('favicon.ico') }}">

<link
    rel="preconnect"
    href="https://fonts.googleapis.com">

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin>

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">

<script>
    if (
        localStorage.getItem('theme') === 'dark' ||
        (
            !localStorage.getItem('theme') &&
            window.matchMedia('(prefers-color-scheme: dark)').matches
        )
    ) {
        document.documentElement.classList.add('dark');
    }
</script>

@vite([
    'resources/css/app.css',
    'resources/js/app.js'
])

</head>

<body
    class="bg-gray-50 text-gray-800 antialiased transition-all duration-300 dark:bg-zinc-950 dark:text-white">

<div class="min-h-screen flex flex-col">

    {{-- TOP BAR --}}
    <div
        class="h-1 bg-gradient-to-r from-orange-500 to-orange-400">
    </div>

    {{-- CONTENT --}}
    <div
        class="flex flex-1 items-center justify-center px-4 py-10">

        <div class="w-full max-w-md">

            {{-- BRAND --}}
            <a
                href="{{ route('menu') }}"
                class="mb-8 flex items-center justify-center gap-3">

                <div
                    class="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500 text-xl text-white shadow-lg">

                    🥟

                </div>

                <div>

                    <h1
                        class="text-xl font-bold text-gray-900 dark:text-white">

                        Dimsum Mak'Angga

                    </h1>

                    <p
                        class="text-xs text-gray-500 dark:text-gray-400">

                        Fresh & Homemade

                    </p>

                </div>

            </a>

            {{-- CARD --}}
            <div
                class="overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-xl dark:border-zinc-800 dark:bg-zinc-900">

                <div class="p-8">

                    @yield('content')

                </div>

            </div>

            {{-- FOOTER --}}
            <p
                class="mt-6 text-center text-xs text-gray-500 dark:text-gray-400">

                © {{ date('Y') }}
                Dimsum Mak'Angga.
                Semua hak dilindungi.

            </p>

        </div>

    </div>

</div>

</body>
</html>
